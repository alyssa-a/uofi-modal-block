# uofi-modal-block
Plugin for a U of I branded modal block
