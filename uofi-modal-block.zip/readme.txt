=== Uofi Modal Block ===
Contributors:      Strategic Communications and Marketing - University of Illinois Urbana-Champaign
Tags:              block
Tested up to:      6.3.2
Stable tag:        1.0.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

Add a modal block with University of Illinois branding.

== Description ==

The modal has two trigger options: icon or button. Both the icon and button styles come from the toolkit, so they are in line with brand guidelines. The modal itself also uses styles from the toolkit.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/uofi-modal-block` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress

== Changelog ==

= 1.0.0 =
* Release
